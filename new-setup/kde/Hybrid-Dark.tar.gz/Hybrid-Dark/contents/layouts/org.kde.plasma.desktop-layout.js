var plasma = getApiVersion(1);

var layout = {
    "desktops": [
        {
            "applets": [
            ],
            "config": {
                "/": {
                    "ItemGeometries-1280x800": "",
                    "ItemGeometries-1623x878": "",
                    "ItemGeometries-1821x921": "",
                    "ItemGeometries-1920x1080": "",
                    "ItemGeometries-1920x1200": "",
                    "ItemGeometriesHorizontal": "",
                    "formfactor": "0",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                },
                "/ConfigDialog": {
                    "DialogHeight": "917",
                    "DialogWidth": "720"
                },
                "/Configuration": {
                    "PreloadWeight": "10"
                },
                "/General": {
                    "ToolBoxButtonState": "topcenter",
                    "ToolBoxButtonX": "379",
                    "ToolBoxButtonY": "44",
                    "arrangement": "1",
                    "positions": "{\"1280x800\":[\"2\",\"6\",\"desktop:/System.desktop\",\"0\",\"1\",\"desktop:/Home.desktop\",\"0\",\"0\",\"desktop:/hybrid-desktop-global-theme.tar.gz\",\"1\",\"2\"],\"1623x878\":[\"1\",\"6\",\"desktop:/System.desktop\",\"0\",\"1\",\"desktop:/Home.desktop\",\"0\",\"0\"],\"1821x921\":[\"1\",\"7\",\"desktop:/System.desktop\",\"0\",\"1\",\"desktop:/Home.desktop\",\"0\",\"0\"],\"1920x1080\":[\"2\",\"8\",\"desktop:/doc-for-hanna.md\",\"1\",\"1\",\"desktop:/Use of Devices-IT policy 2025.pdf\",\"0\",\"5\",\"desktop:/Deploying Learn Locally.pdf\",\"0\",\"3\",\"desktop:/Liferay - 2025 ISMS Policy Handbook (Do Not Share or Distribute).pdf\",\"0\",\"4\",\"desktop:/hc-links.md\",\"1\",\"0\",\"desktop:/Memes\",\"0\",\"2\",\"desktop:/LR Holiday Payday Calendar US 2025.pdf\",\"0\",\"6\",\"desktop:/image.png\",\"0\",\"7\",\"desktop:/System.desktop\",\"0\",\"1\",\"desktop:/Home.desktop\",\"0\",\"0\"],\"1920x1200\":[\"1\",\"10\",\"desktop:/doc-for-hanna.md\",\"0\",\"9\",\"desktop:/Liferay - 2025 ISMS Policy Handbook (Do Not Share or Distribute).pdf\",\"0\",\"5\",\"desktop:/LR Holiday Payday Calendar US 2025.pdf\",\"0\",\"3\",\"desktop:/Deploying Learn Locally.pdf\",\"0\",\"4\",\"desktop:/hc-links.md\",\"0\",\"8\",\"desktop:/Memes\",\"0\",\"2\",\"desktop:/Use of Devices-IT policy 2025.pdf\",\"0\",\"6\",\"desktop:/image.png\",\"0\",\"7\",\"desktop:/System.desktop\",\"0\",\"1\",\"desktop:/Home.desktop\",\"0\",\"0\"]}",
                    "sortMode": "-1"
                },
                "/Wallpaper/org.kde.image/General": {
                    "Image": "/home/sezovr/config/wallpapers/Plasma_K017_HD_NoLogo.png",
                    "PreviewImage": "/home/sezovr/config/wallpapers/Plasma_K017_HD_NoLogo.png",
                    "SlidePaths": "/usr/share/wallpapers/"
                }
            },
            "wallpaperPlugin": "org.kde.image"
        },
        {
            "applets": [
            ],
            "config": {
                "/": {
                    "ItemGeometries-1920x1200": "",
                    "ItemGeometries-2194x1234": "",
                    "ItemGeometries-3840x2400": "",
                    "ItemGeometriesHorizontal": "",
                    "formfactor": "0",
                    "immutability": "1",
                    "lastScreen": "1",
                    "wallpaperplugin": "org.kde.image"
                },
                "/ConfigDialog": {
                    "DialogHeight": "742",
                    "DialogWidth": "1100"
                },
                "/General": {
                    "ToolBoxButtonState": "topcenter",
                    "ToolBoxButtonX": "372",
                    "ToolBoxButtonY": "44",
                    "positions": "{\"1920x1200\":[]}"
                },
                "/Wallpaper/org.kde.image/General": {
                    "Image": "/home/sezovr/config/wallpapers/Fire_Dragon_Nebula_by_casperium.jpg",
                    "PreviewImage": "/home/sezovr/config/wallpapers/Fire_Dragon_Nebula_by_casperium.jpg",
                    "SlidePaths": "/usr/share/wallpapers/"
                }
            },
            "wallpaperPlugin": "org.kde.image"
        }
    ],
    "panels": [
        {
            "alignment": "center",
            "applets": [
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "100",
                            "popupHeight": "526",
                            "popupWidth": "692"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "540",
                            "DialogWidth": "720"
                        },
                        "/General": {
                            "favorites": "firefox.desktop\\,org.kde.dolphin.desktop\\,org.kde.konversation.desktop\\,libreoffice-writer.desktop\\,cantata.desktop\\,kde4-digikam.desktop\\,org.kde.konsole.desktop\\,pamac-manager.desktop\\,pamac-updater.desktop\\,systemsettings.desktop",
                            "favoritesPortedToKAstats": "true",
                            "icon": "plasma",
                            "systemApplications": "systemsettings.desktop\\,org.kde.kinfocenter.desktop",
                            "systemFavorites": "suspend\\,hibernate\\,reboot\\,shutdown"
                        },
                        "/Shortcuts": {
                            "global": "Alt+F1"
                        }
                    },
                    "plugin": "org.kde.plasma.kickoff"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "0"
                        }
                    },
                    "plugin": "org.kde.plasma.showdesktop"
                },
                {
                    "config": {
                        "/": {
                            "localPath": "/home/sezovr/.local/share/plasma_icons/org.kde.dolphin (3).desktop",
                            "url": "file:///usr/share/applications/org.kde.dolphin.desktop"
                        },
                        "/General": {
                            "localPath": "/home/sezovr/.local/share/plasma_icons/org.kde.dolphin.desktop",
                            "url": "file:///usr/share/applications/org.kde.dolphin.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icon"
                },
                {
                    "config": {
                        "/": {
                            "localPath": "/home/sezovr/.local/share/plasma_icons/vifm.desktop",
                            "url": "file:///usr/share/applications/vifm.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icon"
                },
                {
                    "config": {
                        "/": {
                            "localPath": "/home/sezovr/.local/share/plasma_icons/neovide.desktop",
                            "url": "file:///usr/share/applications/neovide.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icon"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "0"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "540",
                            "DialogWidth": "720"
                        },
                        "/General": {
                            "groupingStrategy": "0",
                            "launchers": "applications:worker.desktop,applications:brave-browser.desktop,applications:google-chrome.desktop,applications:org.kde.kontact.desktop,applications:slack.desktop",
                            "showOnlyCurrentActivity": "false",
                            "showOnlyCurrentDesktop": "false"
                        }
                    },
                    "plugin": "org.kde.plasma.icontasks"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "55",
                            "popupHeight": "432",
                            "popupWidth": "444"
                        }
                    },
                    "plugin": "org.kde.netspeedWidget"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "0"
                        }
                    },
                    "plugin": "org.kde.plasma.trash"
                }
            ],
            "config": {
                "/": {
                    "formfactor": "2",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                },
                "/ConfigDialog": {
                    "DialogHeight": "91",
                    "DialogWidth": "1920"
                },
                "/Configuration": {
                    "PreloadWeight": "0"
                }
            },
            "height": 3.611111111111111,
            "hiding": "dodgewindows",
            "location": "bottom",
            "maximumLength": 106.66666666666667,
            "minimumLength": 40.333333333333336,
            "offset": 0
        },
        {
            "alignment": "center",
            "applets": [
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "100",
                            "popupHeight": "435",
                            "popupWidth": "300"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "540",
                            "DialogWidth": "720"
                        },
                        "/General": {
                            "customButtonImage": "desktop-environment-kde",
                            "favoritesPortedToKAstats": "true",
                            "useCustomButtonImage": "true"
                        }
                    },
                    "plugin": "org.kde.plasma.kicker"
                },
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "540",
                            "DialogWidth": "720"
                        },
                        "/General": {
                            "displayedText": "Name",
                            "showWindowOutlines": "false"
                        }
                    },
                    "plugin": "org.kde.plasma.pager"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.panelspacer"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "90",
                            "popupHeight": "476",
                            "popupWidth": "320"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "540",
                            "DialogWidth": "720"
                        },
                        "/General": {
                            "textScrollingBehaviour": "1",
                            "useAlbumCoverAsPanelIcon": "true"
                        }
                    },
                    "plugin": "plasmusic-toolbar"
                },
                {
                    "config": {
                        "/": {
                            "CurrentPreset": "org.kde.plasma.systemmonitor"
                        },
                        "/Appearance": {
                            "chartFace": "org.kde.ksysguard.piechart",
                            "title": "Total CPU Use"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "540",
                            "DialogWidth": "720"
                        },
                        "/SensorColors": {
                            "cpu/all/usage": "28,120,190"
                        },
                        "/Sensors": {
                            "highPrioritySensorIds": "[\"cpu/all/usage\"]",
                            "lowPrioritySensorIds": "[\"cpu/all/cpuCount\",\"cpu/all/coreCount\"]",
                            "totalSensors": "[\"cpu/all/usage\"]"
                        }
                    },
                    "plugin": "org.kde.plasma.systemmonitor"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "72",
                            "popupHeight": "324",
                            "popupWidth": "324"
                        },
                        "/General": {
                            "history": "#a6da95,#8aacf4,#779dcf,#899ca2"
                        }
                    },
                    "plugin": "org.kde.plasma.colorpicker"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "60",
                            "popupHeight": "324",
                            "popupWidth": "324"
                        }
                    },
                    "plugin": "com.dv.fokus"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "100"
                        }
                    },
                    "plugin": "org.kde.plasma.systemtray"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "100",
                            "popupHeight": "450",
                            "popupWidth": "810"
                        },
                        "/Appearance": {
                            "fontWeight": "400",
                            "selectedTimeZones": "America/Recife,Local,UTC,America/Los_Angeles,Europe/Dublin,Europe/Rome,Australia/Sydney,Europe/Helsinki,Europe/Madrid"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "540",
                            "DialogWidth": "720"
                        }
                    },
                    "plugin": "org.kde.plasma.digitalclock"
                },
                {
                    "config": {
                    },
                    "plugin": "com.himdek.kde.plasma.overview"
                }
            ],
            "config": {
                "/": {
                    "formfactor": "2",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                },
                "/ConfigDialog": {
                    "DialogHeight": "84",
                    "DialogWidth": "1920"
                },
                "/Configuration": {
                    "PreloadWeight": "42"
                }
            },
            "height": 2.6666666666666665,
            "hiding": "normal",
            "location": "top",
            "maximumLength": 106.66666666666667,
            "minimumLength": 106.66666666666667,
            "offset": 0
        }
    ],
    "serializationFormatVersion": "1"
}
;

plasma.loadSerializedLayout(layout);
