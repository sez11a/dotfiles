var plasma = getApiVersion(1);

var layout = {
    "desktops": [
        {
            "applets": [
            ],
            "config": {
                "/": {
                    "ItemGeometries-1280x800": "",
                    "ItemGeometries-1623x878": "",
                    "ItemGeometries-1821x921": "",
                    "ItemGeometries-1920x1080": "",
                    "ItemGeometries-1920x1200": "",
                    "ItemGeometriesHorizontal": "",
                    "formfactor": "0",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                },
                "/ConfigDialog": {
                    "DialogHeight": "683",
                    "DialogWidth": "973"
                },
                "/Configuration": {
                    "PreloadWeight": "10"
                },
                "/General": {
                    "ToolBoxButtonState": "topcenter",
                    "ToolBoxButtonX": "365",
                    "ToolBoxButtonY": "44",
                    "arrangement": "1",
                    "positions": "{\"1280x800\":[\"2\"\\,\"6\"\\,\"desktop:/System.desktop\"\\,\"0\"\\,\"1\"\\,\"desktop:/Home.desktop\"\\,\"0\"\\,\"0\"\\,\"desktop:/hybrid-desktop-global-theme.tar.gz\"\\,\"1\"\\,\"2\"]\\,\"1821x921\":[\"1\"\\,\"7\"\\,\"desktop:/System.desktop\"\\,\"0\"\\,\"1\"\\,\"desktop:/Home.desktop\"\\,\"0\"\\,\"0\"]\\,\"1623x878\":[\"1\"\\,\"6\"\\,\"desktop:/System.desktop\"\\,\"0\"\\,\"1\"\\,\"desktop:/Home.desktop\"\\,\"0\"\\,\"0\"]\\,\"1920x1200\":[\"2\"\\,\"10\"\\,\"desktop:/Liferay - 2024 ISMS Policy Handbook.pdf\"\\,\"1\"\\,\"0\"\\,\"desktop:/oldDesktop\"\\,\"0\"\\,\"2\"\\,\"desktop:/2024-01-diamond-bar.md\"\\,\"0\"\\,\"3\"\\,\"desktop:/LiferayCloudComplete.xmind\"\\,\"0\"\\,\"6\"\\,\"desktop:/Memes\"\\,\"0\"\\,\"5\"\\,\"desktop:/System.desktop\"\\,\"0\"\\,\"1\"\\,\"desktop:/Liferay DXP 7.4 Deployment Checklist.pdf\"\\,\"0\"\\,\"8\"\\,\"desktop:/LiferayCloudJustSections.xmind\"\\,\"0\"\\,\"4\"\\,\"desktop:/LXC SM Data Security and Protection.pdf\"\\,\"1\"\\,\"1\"\\,\"desktop:/Home.desktop\"\\,\"0\"\\,\"0\"\\,\"desktop:/elmo.wav\"\\,\"1\"\\,\"2\"]\\,\"1920x1080\":[\"2\"\\,\"9\"\\,\"desktop:/elmo.wav\"\\,\"1\"\\,\"0\"\\,\"desktop:/2024-01-diamond-bar.md\"\\,\"0\"\\,\"4\"\\,\"desktop:/LiferayCloudComplete.xmind\"\\,\"0\"\\,\"5\"\\,\"desktop:/Home.desktop\"\\,\"0\"\\,\"0\"\\,\"desktop:/LiferayCloudJustSections.xmind\"\\,\"0\"\\,\"6\"\\,\"desktop:/System.desktop\"\\,\"0\"\\,\"1\"\\,\"desktop:/Memes\"\\,\"0\"\\,\"2\"\\,\"desktop:/Liferay - 2024 ISMS Policy Handbook.pdf\"\\,\"0\"\\,\"7\"\\,\"desktop:/LXC SM Data Security and Protection.pdf\"\\,\"1\"\\,\"2\"\\,\"desktop:/oldDesktop\"\\,\"0\"\\,\"3\"\\,\"desktop:/Liferay DXP 7.4 Deployment Checklist.pdf\"\\,\"1\"\\,\"1\"]}",
                    "sortMode": "-1"
                },
                "/Wallpaper/org.kde.image/General": {
                    "Image": "/home/sezovr/config/wallpapers/Rings_of_Fire_Single_Wallpaper.jpg",
                    "PreviewImage": "/home/sezovr/config/wallpapers/Rings_of_Fire_Single_Wallpaper.jpg",
                    "SlidePaths": "/usr/share/wallpapers/"
                }
            },
            "wallpaperPlugin": "org.kde.image"
        },
        {
            "applets": [
            ],
            "config": {
                "/": {
                    "ItemGeometries-1920x1200": "",
                    "ItemGeometriesHorizontal": "",
                    "formfactor": "0",
                    "immutability": "1",
                    "lastScreen": "1",
                    "wallpaperplugin": "org.kde.image"
                },
                "/ConfigDialog": {
                    "DialogHeight": "540",
                    "DialogWidth": "720"
                },
                "/General": {
                    "ToolBoxButtonState": "topcenter",
                    "ToolBoxButtonX": "372",
                    "ToolBoxButtonY": "44"
                },
                "/Wallpaper/org.kde.image/General": {
                    "Image": "/home/sezovr/config/Widescreen/Beautiful Dream - 1920 x 1080.png",
                    "SlidePaths": "/usr/share/wallpapers/"
                }
            },
            "wallpaperPlugin": "org.kde.image"
        }
    ],
    "panels": [
        {
            "alignment": "center",
            "applets": [
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "100",
                            "popupHeight": "526",
                            "popupWidth": "675"
                        },
                        "/General": {
                            "favorites": "firefox.desktop\\,org.kde.dolphin.desktop\\,org.kde.konversation.desktop\\,libreoffice-writer.desktop\\,cantata.desktop\\,kde4-digikam.desktop\\,org.kde.konsole.desktop\\,pamac-manager.desktop\\,pamac-updater.desktop\\,systemsettings.desktop",
                            "favoritesPortedToKAstats": "true",
                            "systemApplications": "systemsettings.desktop\\,org.kde.kinfocenter.desktop"
                        },
                        "/Shortcuts": {
                            "global": "Alt+F1"
                        }
                    },
                    "plugin": "org.kde.plasma.kickoff"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "0"
                        }
                    },
                    "plugin": "org.kde.plasma.showdesktop"
                },
                {
                    "config": {
                        "/": {
                            "localPath": "/home/sezovr/.local/share/plasma_icons/org.kde.dolphin (3).desktop",
                            "url": "file:///usr/share/applications/org.kde.dolphin.desktop"
                        },
                        "/General": {
                            "localPath": "/home/sezovr/.local/share/plasma_icons/org.kde.dolphin.desktop",
                            "url": "file:///usr/share/applications/org.kde.dolphin.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icon"
                },
                {
                    "config": {
                        "/": {
                            "localPath": "/home/sezovr/.local/share/plasma_icons/org.kde.krusader (3).desktop",
                            "url": "file:///usr/share/applications/org.kde.krusader.desktop"
                        },
                        "/General": {
                            "localPath": "/home/sezovr/.local/share/plasma_icons/org.kde.krusader.desktop",
                            "url": "file:///usr/share/applications/org.kde.krusader.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icon"
                },
                {
                    "config": {
                        "/": {
                            "localPath": "/home/sezovr/.local/share/plasma_icons/ranger.desktop",
                            "url": "file:///usr/share/applications/ranger.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icon"
                },
                {
                    "config": {
                        "/": {
                            "localPath": "/home/sezovr/.local/share/plasma_icons/neovide.desktop",
                            "url": "file:///usr/share/applications/neovide.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icon"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "0"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "540",
                            "DialogWidth": "720"
                        },
                        "/General": {
                            "groupingStrategy": "0",
                            "launchers": "applications:brave-browser.desktop,applications:google-chrome.desktop,applications:org.kde.kontact.desktop,applications:slack.desktop",
                            "showOnlyCurrentActivity": "false",
                            "showOnlyCurrentDesktop": "false"
                        }
                    },
                    "plugin": "org.kde.plasma.icontasks"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "0"
                        }
                    },
                    "plugin": "org.kde.plasma.trash"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "55",
                            "popupHeight": "432",
                            "popupWidth": "444"
                        }
                    },
                    "plugin": "org.kde.netspeedWidget"
                }
            ],
            "config": {
                "/": {
                    "formfactor": "2",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                },
                "/ConfigDialog": {
                    "DialogHeight": "91",
                    "DialogWidth": "1920"
                },
                "/Configuration": {
                    "PreloadWeight": "0"
                }
            },
            "height": 3.611111111111111,
            "hiding": "autohide",
            "location": "bottom",
            "maximumLength": 106.66666666666667,
            "minimumLength": 40.333333333333336,
            "offset": 0
        },
        {
            "alignment": "center",
            "applets": [
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "100",
                            "popupHeight": "438",
                            "popupWidth": "298"
                        },
                        "/General": {
                            "favoritesPortedToKAstats": "true"
                        }
                    },
                    "plugin": "org.kde.plasma.kicker"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "42"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "840"
                        },
                        "/General": {
                            "containmentType": "Plasma",
                            "visibility": "ActiveMaximizedWindow"
                        }
                    },
                    "plugin": "org.kde.windowbuttons"
                },
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "540",
                            "DialogWidth": "720"
                        },
                        "/General": {
                            "filterActivityInfo": "false",
                            "filterByScreen": "true",
                            "placeHolder": "Desktop"
                        }
                    },
                    "plugin": "org.kde.windowtitle"
                },
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "540",
                            "DialogWidth": "720"
                        }
                    },
                    "plugin": "org.kde.plasma.appmenu"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.panelspacer"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "60",
                            "popupHeight": "478",
                            "popupWidth": "320"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "540",
                            "DialogWidth": "720"
                        },
                        "/General": {
                            "textScrollingBehaviour": "1",
                            "useAlbumCoverAsPanelIcon": "true"
                        }
                    },
                    "plugin": "plasmusic-toolbar"
                },
                {
                    "config": {
                        "/": {
                            "CurrentPreset": "org.kde.plasma.systemmonitor"
                        },
                        "/Appearance": {
                            "chartFace": "org.kde.ksysguard.piechart",
                            "title": "Total CPU Use"
                        },
                        "/SensorColors": {
                            "cpu/all/usage": "28,120,190"
                        },
                        "/Sensors": {
                            "highPrioritySensorIds": "[\"cpu/all/usage\"]",
                            "lowPrioritySensorIds": "[\"cpu/all/cpuCount\",\"cpu/all/coreCount\"]",
                            "totalSensors": "[\"cpu/all/usage\"]"
                        }
                    },
                    "plugin": "org.kde.plasma.systemmonitor"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "42"
                        }
                    },
                    "plugin": "org.kde.plasma.colorpicker"
                },
                {
                    "config": {
                    },
                    "plugin": "com.dv.fokus"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "100"
                        }
                    },
                    "plugin": "org.kde.plasma.systemtray"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "100",
                            "popupHeight": "450",
                            "popupWidth": "810"
                        },
                        "/Appearance": {
                            "fontWeight": "400",
                            "selectedTimeZones": "America/Los_Angeles,Local,America/Recife,Europe/Dublin,Europe/Rome,Europe/Madrid,Europe/Helsinki,Australia/Sydney"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "540",
                            "DialogWidth": "720"
                        }
                    },
                    "plugin": "org.kde.plasma.digitalclock"
                },
                {
                    "config": {
                    },
                    "plugin": "com.himdek.kde.plasma.overview"
                }
            ],
            "config": {
                "/": {
                    "formfactor": "2",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                },
                "/ConfigDialog": {
                    "DialogHeight": "84",
                    "DialogWidth": "1920"
                },
                "/Configuration": {
                    "PreloadWeight": "42"
                }
            },
            "height": 2.4444444444444446,
            "hiding": "normal",
            "location": "top",
            "maximumLength": 106.66666666666667,
            "minimumLength": 106.66666666666667,
            "offset": 0
        },
        {
            "alignment": "center",
            "applets": [
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "540",
                            "DialogWidth": "720"
                        },
                        "/General": {
                            "containmentType": "Plasma",
                            "visibility": "ActiveMaximizedWindow"
                        }
                    },
                    "plugin": "org.kde.windowbuttons"
                },
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "540",
                            "DialogWidth": "720"
                        },
                        "/General": {
                            "filterActivityInfo": "false",
                            "filterByScreen": "true",
                            "placeHolder": "Desktop"
                        }
                    },
                    "plugin": "org.kde.windowtitle"
                },
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "540",
                            "DialogWidth": "720"
                        }
                    },
                    "plugin": "org.kde.plasma.appmenu"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.panelspacer"
                },
                {
                    "config": {
                        "/Appearance": {
                            "fontWeight": "400"
                        }
                    },
                    "plugin": "org.kde.plasma.digitalclock"
                }
            ],
            "config": {
                "/": {
                    "formfactor": "2",
                    "immutability": "1",
                    "lastScreen": "1",
                    "wallpaperplugin": "org.kde.image"
                },
                "/ConfigDialog": {
                    "DialogHeight": "84",
                    "DialogWidth": "1920"
                }
            },
            "height": 2.4444444444444446,
            "hiding": "normal",
            "location": "top",
            "maximumLength": 106.66666666666667,
            "minimumLength": 106.66666666666667,
            "offset": 0
        }
    ],
    "serializationFormatVersion": "1"
}
;

plasma.loadSerializedLayout(layout);
