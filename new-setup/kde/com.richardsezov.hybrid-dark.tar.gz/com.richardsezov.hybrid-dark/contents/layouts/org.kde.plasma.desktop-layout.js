// Desktop Icons 
var allDesktops = desktops();
var mainDesktop = allDesktops[0];
mainDesktop.currentConfigGroup = ["General"]
mainDesktop.writeConfig("arrangement","1")
mainDesktop.wallpaperPlugin = 'org.kde.image'; // Use the static image plugin
mainDesktop.currentConfigGroup = Array('Wallpaper', 'org.kde.image', 'General');
    
mainDesktop.writeConfig('Image', 'file:///usr/share/wallpapers/hybrid.jpg'); 
mainDesktop.writeConfig('FillMode', '2');

// Bottom Panel 
var panel = new Panel 
var panelScreen = panel.screen 

panel.location = "bottom";
panel.height = 48
panel.alignment = "left";
panel.lengthMode = "custom";
panel.floating = true 
panel.currentConfigGroup = Array("HiddenStatus")
panel.writeConfig("autoHide", "true")
panel.writeConfig("autoHideMode", "3")
geo = screenGeometry(panelScreen); 

panel.minimumLength = geo.width * 9 / 16 
panel.maximumLength = geo.width * 9 / 16

let kickoffIcon = panel.addWidget("org.kde.plasma.kickoff")
// kickoffIcon.currentConfigGroup = ["General"]
// kickoffIcon.writeConfig("icon","plasmashell")

panel.addWidget("org.kde.plasma.showdesktop")

let dolphinIcon = panel.addWidget("org.kde.plasma.icon")
dolphinIcon.currentConfigGroup = ["General"]
dolphinIcon.writeConfig("url", "file:///usr/share/applications/org.kde.dolphin.desktop")

let rangerIcon = panel.addWidget("org.kde.plasma.icon")
rangerIcon.currentConfigGroup = ["General"]
rangerIcon.writeConfig("url", "file:///usr/share/applications/ranger.desktop")

let taskBar = panel.addWidget("org.kde.plasma.icontasks")
taskBar.currentConfigGroup = ["General"]
taskBar.writeConfig("launchers",["applications:brave-browser.desktop","applications:org.kde.kontact.desktop"])

let netSpeed = panel.addWidget("org.kde.plasma.systemmonitor.net")
netSpeed.currentConfigGroup = ["Appearance"]
netSpeed.writeConfig("chartFace","org.kde.ksysguard.textonly")

panel.addWidget("org.kde.plasma.trash")

// Top Panel 
var panelTop = new Panel
panelTop.height = 28; 
panelTop.location = "top"; 
panelTop.alignment = "center";
panelTop.lengthMode = "fillavailable" 
panelTop.floating = false

let kickerIcon = panelTop.addWidget("org.kde.plasma.kicker")
kickerIcon.currentConfigGroup = ["General"]
kickerIcon.writeConfig("icon","start-here-kde-plasma")

panelTop.addWidget("org.kde.plasma.pager")
panelTop.addWidget("org.kde.plasma.panelspacer")
panelTop.addWidget("plasmusic-toolbar")

let cpuMonitor = panelTop.addWidget("org.kde.plasma.systemmonitor")
cpuMonitor.currentConfigGroup = ["Appearance"]
cpuMonitor.writeConfig("chartFace", "org.kde.ksysguard.piechart")

panelTop.addWidget("org.kde.plasma.colorpicker")
panelTop.addWidget("com.dv.fokus")
panelTop.addWidget("org.kde.plasma.systemtray")
panelTop.addWidget("org.kde.plasma.digitalclock")
panelTop.addWidget("com.himdek.kde.plasma.overview")
