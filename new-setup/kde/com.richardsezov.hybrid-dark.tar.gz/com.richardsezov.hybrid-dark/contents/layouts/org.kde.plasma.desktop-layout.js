// Desktop Icons 
var allDesktops = desktops();
var mainDesktop = allDesktops[0];
mainDesktop.currentConfigGroup = ["General"]
mainDesktop.writeConfig("arrangement","1")

// Bottom Panel 
var panel = new Panel 
var panelScreen = panel.screen 

panel.location = "bottom";
panel.height = 48
panel.alignment = "left";
panel.lengthMode = "custom";
panel.floating = true 
geo = screenGeometry(panelScreen); 

panel.minimumLength = geo.width * 9 / 16 
panel.maximumLength = geo.width * 9 / 16

let kickoffIcon = panel.addWidget("org.kde.plasma.kickoff")
kickoffIcon.currentConfigGroup = ["General"]
kickoffIcon.writeConfig("icon","plasmashell")

panel.addWidget("org.kde.plasma.showdesktop")

let dolphinIcon = panel.addWidget("org.kde.plasma.icon")
dolphinIcon.currentConfigGroup = ["General"]
dolphinIcon.writeConfig("url", "file:///usr/share/applications/org.kde.dolphin.desktop")

let vifmIcon = panel.addWidget("org.kde.plasma.icon")
vifmIcon.currentConfigGroup = ["General"]
vifmIcon.writeConfig("url", "file:///usr/share/applications/vifm.desktop")

let neovideIcon = panel.addWidget("org.kde.plasma.icon")
neovideIcon.currentConfigGroup = ["General"]
neovideIcon.writeConfig("url", "file:///usr/share/applications/neovide.desktop")

let taskBar = panel.addWidget("org.kde.plasma.icontasks")
taskBar.currentConfigGroup = ["General"]
taskBar.writeConfig("launchers",["applications:worker.desktop","applications:brave-browser.desktop","applications:org.kde.kontact.desktop"])

let netSpeed = panel.addWidget("org.kde.plasma.systemmonitor.net")
netSpeed.currentConfigGroup = ["Appearance"]
netSpeed.writeConfig("chartFace","org.kde.ksysguard.textonly")

panel.addWidget("org.kde.plasma.trash")

// Top Panel 
var panelTop = new Panel
panelTop.height = 28; 
panelTop.location = "top"; 
panelTop.alignment = "center";
panelTop.lengthMode = "fillavailable" 
panelTop.floating = false

let kickerIcon = panelTop.addWidget("org.kde.plasma.kicker")
kickerIcon.currentConfigGroup = ["General"]
kickerIcon.writeConfig("icon","plasmashell")

panelTop.addWidget("org.kde.plasma.pager")
panelTop.addWidget("org.kde.plasma.panelspacer")
panelTop.addWidget("plasmusic-toolbar")

let cpuMonitor = panel.addWidget("org.kde.plasma.systemmonitor")
cpuMonitor.currentConfigGroup = ["Appearance"]
cpuMonitor.writeConfig("chartFace", "org.kde.ksysguard.piechart")

panelTop.addWidget("org.kde.plasma.colorpicker")
panelTop.addWidget("com.dv.fokus")
panelTop.addWidget("org.kde.plasma.systemtray")
panelTop.addWidget("org.kde.plasma.digitalclock")
