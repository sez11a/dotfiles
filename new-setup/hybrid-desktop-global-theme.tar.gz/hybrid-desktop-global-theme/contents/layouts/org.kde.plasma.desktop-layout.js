var plasma = getApiVersion(1);

var layout = {
    "desktops": [
        {
            "applets": [
            ],
            "config": {
                "/": {
                    "ItemGeometries-1280x800": "",
                    "ItemGeometriesHorizontal": "",
                    "formfactor": "0",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                },
                "/ConfigDialog": {
                    "DialogHeight": "550",
                    "DialogWidth": "928"
                },
                "/Configuration": {
                    "PreloadWeight": "10"
                },
                "/General": {
                    "ToolBoxButtonState": "top",
                    "ToolBoxButtonX": "538",
                    "ToolBoxButtonY": "24",
                    "arrangement": "1",
                    "positions": "{\"1280x800\":[\"1\"\\,\"5\"\\,\"desktop:/Home.desktop\"\\,\"0\"\\,\"0\"\\,\"desktop:/System.desktop\"\\,\"0\"\\,\"1\"]}",
                    "sortMode": "-1"
                },
                "/Wallpaper/org.kde.image/General": {
                    "Image": "file:///usr/share/wallpapers/Caledonia/contents/images/1920x1200.jpeg"
                }
            },
            "wallpaperPlugin": "org.kde.image"
        }
    ],
    "panels": [
        {
            "alignment": "center",
            "applets": [
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "100"
                        },
                        "/General": {
                            "favorites": "firefox.desktop\\,org.kde.dolphin.desktop\\,org.kde.konversation.desktop\\,libreoffice-writer.desktop\\,cantata.desktop\\,kde4-digikam.desktop\\,org.kde.konsole.desktop\\,pamac-manager.desktop\\,pamac-updater.desktop\\,systemsettings.desktop",
                            "favoritesPortedToKAstats": "true",
                            "systemApplications": "systemsettings.desktop\\,org.kde.kinfocenter.desktop"
                        },
                        "/Shortcuts": {
                            "global": "Alt+F1"
                        }
                    },
                    "plugin": "org.kde.plasma.kickoff"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "0"
                        }
                    },
                    "plugin": "org.kde.plasma.showdesktop"
                },
                {
                    "config": {
                        "/": {
                            "localPath": "/home/sezovr/.local/share/plasma_icons/org.kde.dolphin.desktop",
                            "url": "file:///usr/share/applications/org.kde.dolphin.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icon"
                },
                {
                    "config": {
                        "/": {
                            "localPath": "/home/sezovr/.local/share/plasma_icons/org.kde.konsole.desktop",
                            "url": "file:///usr/share/applications/org.kde.konsole.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icon"
                },
                {
                    "config": {
                        "/": {
                            "localPath": "/home/sezovr/.local/share/plasma_icons/org.kde.krusader.desktop",
                            "url": "file:///usr/share/applications/org.kde.krusader.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icon"
                },
                {
                    "config": {
                        "/": {
                            "localPath": "/home/sezovr/.local/share/plasma_icons/brave-browser.desktop",
                            "url": "file:///usr/share/applications/brave-browser.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icon"
                },
                {
                    "config": {
                        "/": {
                            "localPath": "/home/sezovr/.local/share/plasma_icons/org.kde.kontact.desktop",
                            "url": "file:///usr/share/applications/org.kde.kontact.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icon"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "0"
                        },
                        "/General": {
                            "launchers": ""
                        }
                    },
                    "plugin": "org.kde.plasma.icontasks"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "0"
                        }
                    },
                    "plugin": "org.kde.plasma.trash"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.netspeedWidget"
                }
            ],
            "config": {
                "/": {
                    "formfactor": "2",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                },
                "/ConfigDialog": {
                    "DialogHeight": "91",
                    "DialogWidth": "1280"
                },
                "/Configuration": {
                    "PreloadWeight": "0"
                }
            },
            "height": 2.772727272727273,
            "hiding": "normal",
            "location": "bottom",
            "maximumLength": 58.18181818181818,
            "minimumLength": 40.36363636363637,
            "offset": 0
        },
        {
            "alignment": "left",
            "applets": [
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "92"
                        },
                        "/General": {
                            "favoritesPortedToKAstats": "true"
                        }
                    },
                    "plugin": "org.kde.plasma.kicker"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "42"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "840"
                        },
                        "/General": {
                            "containmentType": "Plasma",
                            "visibility": "ActiveMaximizedWindow"
                        }
                    },
                    "plugin": "org.kde.windowbuttons"
                },
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "840"
                        },
                        "/General": {
                            "containmentType": "Plasma",
                            "fillWidth": "true",
                            "filterByScreen": "true"
                        }
                    },
                    "plugin": "org.kde.windowappmenu"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "42"
                        }
                    },
                    "plugin": "org.kde.plasma.colorpicker"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "47"
                        }
                    },
                    "plugin": "org.kde.plasma.systemtray"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "42"
                        }
                    },
                    "plugin": "org.kde.plasma.digitalclock"
                },
                {
                    "config": {
                        "/": {
                            "PreloadWeight": "42"
                        }
                    },
                    "plugin": "org.kde.plasma.activitypager"
                }
            ],
            "config": {
                "/": {
                    "formfactor": "2",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                },
                "/ConfigDialog": {
                    "DialogHeight": "91",
                    "DialogWidth": "1280"
                },
                "/Configuration": {
                    "PreloadWeight": "42"
                }
            },
            "height": 1.0909090909090908,
            "hiding": "normal",
            "location": "top",
            "maximumLength": 58.18181818181818,
            "minimumLength": 58.18181818181818,
            "offset": 0
        }
    ],
    "serializationFormatVersion": "1"
}
;

plasma.loadSerializedLayout(layout);
